library(testthat)
library(RISC)

test_check("RISC")
